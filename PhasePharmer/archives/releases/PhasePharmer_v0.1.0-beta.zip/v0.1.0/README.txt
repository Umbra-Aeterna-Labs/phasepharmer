Phase Pharmer v0.1.0
A mushroom farming tool for Project: Gorgon, an excellent MMORPG

Phase Pharmer is a JavaScript program that calculates the  current
phase of the moon and provides useful fungal growth information
for avid mushroom farmers.

Written in JavaScript.

https://projectgorgon.com


CHANGELOG
* 14 May 2019: [v0.1.0 (beta)](PhasePharmer_0.1.0-beta.zip) released


INSTRUCTIONS
* Download the latest version of Phase Pharmer
* Extract all files to a local folder
* Open PhasePharmer.html in a browser of your choice (IE/Edge untested)
* "Today's Phase" is the calculated moon phase
* Select a phase from the drop-down to view more info
* Every time the page is loaded the phase is recalculated


FILE STRUCTURE

{version}/
    LICENSE
    PhasePharmer.html
    PhasePharmer_0.1.0-beta.zip
    README.md
    images/
        *.png
    static/
        script.js
        style.css


TOOLS
* WebStorm - IDE by Jetbrains v2018.2
    https://www.jetbrains.com/webstorm
* GIMP - GNU Image Manipulation Program v2.10.8
    https://www.gimp.org


ATTRIBUTION
* This project is licensed under the MIT License (MIT)

Copyright (c) 2019 Chris Mabon
