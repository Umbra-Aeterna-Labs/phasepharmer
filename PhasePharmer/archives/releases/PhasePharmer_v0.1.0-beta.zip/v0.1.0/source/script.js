/*
    The MIT License (MIT)

    Copyright (c) 2019 Chris Mabon

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
    THE SOFTWARE.
 */

let moonPhases = [
    '🌑New Moon🌑'
    , '🌒Waxing Crescent🌒'
    , '🌓First Quarter🌓'
    , '🌔Waxing Gibbous🌔'
    , '🌕Full Moon🌕'
    , '🌖Waning Gibbous🌖'
    , '🌗Last Quarter🌗'
    , '🌘Waning Crescent🌘'
];

/*
 * Algorithm credit http://www.voidware.com/moon_phase.htm
 * Retrieved 13 May 2019
 */
function currPhase(year, month, day) {
    /*
      calculates the moon phase (0-7), accurate to 1 segment.
      0 = > new moon.
      4 => full moon.
      */
    if (month < 3) {
        year--;
        month += 12;
    }
    month++;
    let c = 365.25 * year;
    let e = 30.6 * month;
    let jd = c + e + day - 694039.09;   // jd is total days elapsed
    jd /= 29.53;                        // divide by the moon cycle (29.53 days)
    let b = Math.floor(jd);             // take integer part of jd
    jd -= b;                            // subtract integer part to leave fractional part of original jd
    b = Math.round(jd * 8);             // scale fraction from 0-8 and round fraction (library method)
    // b = jd * 8 + 0.5;                // " " round fraction (mathematical method)
    (b >= 8) ? b = 0 : b;                // 0 and 8 are the same so turn 8 into 0

    return b;
}

function phaseName(phase) {

    return moonPhases[phase];
}

function shroomGrowth() {
    let subs = [
        'Organs'    // 0
        , 'Limbs'   // 1
        , 'Exotic'  // 2
        , 'Dirt'    // 3
        , 'Bone'    // 4
        , 'Meat'    // 5
        , 'unknown' // 6
    ];

    let mus = [
        ['Parasol', 2, subs[0], subs[3], 'images/parasol.png']
        , ['Mycena', 3, subs[1], subs[4], 'images/mycena.png']
        , ['Boletus', 4, subs[2], subs[5], 'images/boletus.png']
        , ['Field', 5, subs[0], subs[4], 'images/field.png']
        , ['Goblin Puffball', 5, subs[2], subs[3], 'images/goblin.png']
        , ['Blusher', 6, subs[2], subs[5], 'images/blusher.png']
        , ['Milk Cap', 7, subs[0], subs[3], 'images/milk.png']
        , ['Blastcap', 8, subs[0], subs[5], 'images/blastcap.png']
        , ['Blood', 8, subs[1], subs[3], 'images/blood.png']
        , ['Coral', 9, subs[1], subs[5], 'images/coral.png']
        , ['Iocaine', 10, subs[1], subs[4], 'images/iocaine.png']
        , ['Groxmax', 11, subs[0], subs[4], 'images/groxmax.png']
        , ['False Agaric', 12, subs[1], subs[4], 'images/false.png']
        , ['Porcini', 12, subs[2], subs[5], 'images/porcini.png']
        , ['Black Foot Morel', 13, subs[2], subs[3], 'images/black.png']
        , ['Wizard\'s', 13, subs[0], subs[4], 'images/wizards.png']
        , ['Pixie\'s Parasol', 14, subs[0], subs[5], 'images/pixies.png']
        , ['Fly Amanita', 15, subs[0], subs[4], 'images/fly.png']
        , ['Charged Mycelium', 0, subs[6], subs[6], 'images/charged.png']
    ];

    let robustly = [
        // new moon
        [mus[2], mus[4], mus[5], mus[14]]
        // waxing crescent
        , [mus[1], mus[8], mus[10], mus[15], mus[17]]
        // first quarter
        , [mus[1], mus[9], mus[10], mus[15], mus[16]]
        // waxing gibbous
        , [mus[3], mus[4], mus[9], mus[11], mus[16]]
        // full moon
        , [mus[0], mus[6], mus[7], mus[13], mus[17]]
        // waning gibbous
        , [mus[2], mus[5], mus[7], mus[13]]
        // last quarter
        , [mus[3], mus[8], mus[11], mus[12]]
        // waning crescent
        , [mus[0], mus[6], mus[12], mus[14]]
    ];

    let today = new Date(Date.now());
    let s = today.getUTCSeconds();
    let mi = today.getUTCMinutes();
    let h = today.getUTCHours() - 4;
    let d = today.getUTCDate();
    let mo = today.getUTCMonth();
    let y = today.getUTCFullYear();
    let phaser = document.getElementById('phase');

    let svrTime = new Date(y, mo, d, h, mi, s, 0);
    let phase = moonPhases[currPhase(svrTime.getFullYear(), svrTime.getMonth(), svrTime.getDate())];
    let phaseDisplay = document.getElementById('phase_display');
    phaseDisplay.appendChild(phaseDisplay.ownerDocument.createTextNode(phase));

    for (let p in moonPhases) {
        let option = document.createElement('option');
        option.text = moonPhases[p];
        phaser.add(option);
        option.value = phase;
    }


    let tbl = document.getElementById('viable_shrooms');

    phaser.addEventListener('change', (event) => {

        tbl.innerHTML = '';

        let header = tbl.createTHead();
        let row = header.insertRow(0);
        let icon = row.insertCell(0);
        let name = row.insertCell(1);
        let grwTime = row.insertCell(2);
        let highSubs = row.insertCell(3);
        let lowSubs = row.insertCell(4);

        icon.appendChild(name.ownerDocument.createTextNode('Icon'));
        name.appendChild(name.ownerDocument.createTextNode('Mushroom'));
        grwTime.appendChild(name.ownerDocument.createTextNode('Time'));
        highSubs.appendChild(name.ownerDocument.createTextNode('High Yield'));
        lowSubs.appendChild(name.ownerDocument.createTextNode('Low Yield'));

        let body = tbl.createTBody();
        let phaseNum = phaser.selectedIndex;

        for (let shrooms in robustly[phaseNum]) {
            let row = body.insertRow(shrooms);
            let mushPic = row.insertCell(0);
            let img = document.createElement('img');
            img.src = robustly[phaseNum][shrooms][4];
            img.width = '46';
            img.height = '46';
            mushPic.appendChild(img);
            let name = row.insertCell(1);
            let grwTime = row.insertCell(2);
            let highSubs = row.insertCell(3);
            let lowSubs = row.insertCell(4);

            name.appendChild(name.ownerDocument.createTextNode(robustly[phaseNum][shrooms][0]));
            grwTime.appendChild(name.ownerDocument.createTextNode(robustly[phaseNum][shrooms][1] + ' hours'));
            highSubs.appendChild(name.ownerDocument.createTextNode(robustly[phaseNum][shrooms][2]));
            lowSubs.appendChild(name.ownerDocument.createTextNode(robustly[phaseNum][shrooms][3]));
        }
    });

    let event = new Event('change');
    phaser.dispatchEvent(event);
}

shroomGrowth();