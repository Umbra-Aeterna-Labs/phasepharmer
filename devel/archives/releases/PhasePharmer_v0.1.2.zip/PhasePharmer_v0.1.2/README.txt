### Phase Pharmer ###

A mushroom farming tool for Project: Gorgon (an excellent MMORPG)

Phase Pharmer is a web app that calculates the  current
phase of the moon and provides useful fungal growth information
for avid mushroom farmers

Written in JavaScript

Project: Gorgon website - https://projectgorgon.com


## INSTRUCTIONS ##

Consult the wiki if you have questions:

https://github.com/chrismabon/PhasePharmer/wiki


## LICENSE & COPYRIGHT ##

This project is licensed under GPL-2.0

Copyright &copy; 2019 Chris Mabon
