# Phase Pharmer

Phase Pharmer is a mushroom farming web app for
Project: Gorgon (https://projectgorgon.com).
The app calculates the current phase of the moon and provides useful
fungal growth information for avid mushroom farmers.

Please see the Wiki for setup and usage.


## WIKI
    https://github.com/duo-extrema-software/PhasePharmer/wiki

## LICENSE
    https://github.com/duo-extrema-software/PhasePharmer/blob/master/LICENSE

## DOWNLOAD
    https://github.com/duo-extrema-software/PhasePharmer/releases


Copyright (C) 2019 Duo Extrema Software
