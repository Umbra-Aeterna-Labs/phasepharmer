/*
    The MIT License (MIT)

    Copyright (c) 2019 Chris Mabon

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
    THE SOFTWARE.
 */

// const lune = require('lune');

let iconSize = 36;
let hoursPerPhase = 88.59;
let daysPerPhase = 3.69125;

let moonPhases = [
    '🌑New Moon🌑'
    , '🌒Waxing Crescent🌒'
    , '🌓First Quarter🌓'
    , '🌔Waxing Gibbous🌔'
    , '🌕Full Moon🌕'
    , '🌖Waning Gibbous🌖'
    , '🌗Last Quarter🌗'
    , '🌘Waning Crescent🌘'
];

let moonPhasesTxt = [
    'New Moon'
    , 'Waxing Crescent'
    , 'First Quarter'
    , 'Waxing Gibbous'
    , 'Full Moon'
    , 'Waning Gibbous'
    , 'Last Quarter'
    , 'Waning Crescent'
];

let subs = [
    'Organs'    // 0
    , 'Limbs'   // 1
    , 'Exotic'  // 2
    , 'Dirt'    // 3
    , 'Bone'    // 4
    , 'Meat'    // 5
];

let boxMods = [
    [0.8, '▪Grow Time: 20% faster than normal']
    , [0.6, '▪Grow Time: 40% faster than normal']
    , [1.25, '▪Grow Time: 25% slower per crop']
    , [1.5, '▪Grow Time: 50% slower for each crop']
    , [2.0, '▪Grow Time: 100% slower than normal']
    , [1, '▪Chance for Second Mushroom Type: 15% per crop']
    , [1, '▪Chance for Second Mushroom Type: 33%']
    , [1, '▪Yield: +100% mushrooms per crop']
    , [1, '▪Yield: +200% more mushrooms than normal']
    , [1, '▪XP: +33% more per mushroom']
    , [1, '▪XP Penalty: -50% XP per mushroom']
    , [1, '▪Note: this box requires 2 doses of substrate']
    , [1, '']
];

let boxes = [
    ['Mushroom Box', [boxMods[12]]]
    , ['Lucky Box', [boxMods[6]]]
    , ['Practice Box', [boxMods[2], boxMods[9]]]
    , ['Epic Crop Box', [boxMods[4], boxMods[8], boxMods[11]]]
    , ['Fast Box', [boxMods[0], boxMods[10]]]
    , ['High Yield Box', [boxMods[3], boxMods[5], boxMods[11]]]
    , ['Very Fast Box', [boxMods[1], boxMods[10]]]
];

let mus = [
    ['Parasol', 2, subs[0], subs[3], 'img/parasol.png', [4, 7], [0, 3]]
    , ['Mycena', 3, subs[1], subs[4], 'img/mycena.png', [1, 2], [5, 6]]
    , ['Boletus', 4, subs[2], subs[5], 'img/boletus.png', [0, 5], [1, 4]]
    , ['Field', 5, subs[0], subs[4], 'img/field.png', [3, 6], [2, 7]]
    , ['Goblin Puffball', 5, subs[2], subs[3], 'img/goblin.png', [0, 3], [4, 7]]
    , ['Blusher', 6, subs[2], subs[5], 'img/blusher.png', [0, 5], [1, 4]]
    , ['Milk Cap', 7, subs[0], subs[3], 'img/milk.png', [4, 7], [0, 3]]
    , ['Blastcap', 8, subs[0], subs[5], 'img/blastcap.png', [4, 5], [0, 1]]
    , ['Blood', 8, subs[1], subs[3], 'img/blood.png', [1, 6], [2, 3]]
    , ['Coral', 9, subs[1], subs[5], 'img/coral.png', [2, 3], [6, 7]]
    , ['Iocaine', 10, subs[1], subs[4], 'img/iocaine.png', [1, 2], [5, 6]]
    , ['Groxmax', 11, subs[0], subs[4], 'img/groxmax.png', [3, 6], [2, 7]]
    , ['False Agaric', 12, subs[1], subs[4], 'img/false.png', [6, 7], [2, 3]]
    , ['Porcini', 12, subs[2], subs[5], 'img/porcini.png', [4, 5], [0, 1]]
    , ['Black Foot Morel', 13, subs[2], subs[3], 'img/black.png', [0, 7], [6, 6]]
    , ['Wizard\'s', 13, subs[0], subs[4], 'img/wizards.png', [1, 2], [3, 6]]
    , ['Pixie\'s Parasol', 14, subs[0], subs[5], 'img/pixies.png', [2, 3], [6, 7]]
    , ['Fly Amanita', 15, subs[0], subs[4], 'img/fly.png', [1, 4], [0, 5]]
];

let robustly = [
    // new moon
    [mus[2], mus[4], mus[5], mus[14]]
    // waxing crescent
    , [mus[1], mus[8], mus[10], mus[15], mus[17]]
    // first quarter
    , [mus[1], mus[9], mus[10], mus[15], mus[16]]
    // waxing gibbous
    , [mus[3], mus[4], mus[9], mus[11], mus[16]]
    // full moon
    , [mus[0], mus[6], mus[7], mus[13], mus[17]]
    // waning gibbous
    , [mus[2], mus[5], mus[7], mus[13]]
    // last quarter
    , [mus[3], mus[8], mus[11], mus[12]]
    // waning crescent
    , [mus[0], mus[6], mus[12], mus[14]]
];

function phaseName(phase) {
    if (Number.isInteger(phase)) {
        return moonPhases[phase];
    }
    else {
        return moonPhases[phaseInt(phase)];
    }

}

function timeToNextPhase(year, month, day, hour = 0) {
    let currPhase = phaseAt(year, month, day, hour);
    // console.log('currPhase ' + currPhase);
    let phaseProgress = 0.0;

    if ((currPhase.valueOf() < 1.0) && (currPhase.valueOf() >= 0.875)) {
        phaseProgress = currPhase.valueOf() - 0.875;
    }
    else if ((currPhase.valueOf() < 0.875) && (currPhase.valueOf() >= 0.75)) {
        phaseProgress = currPhase.valueOf() - 0.75;
    }
    else if ((currPhase.valueOf() < 0.75) && (currPhase.valueOf() >= 0.625)) {
        phaseProgress = currPhase.valueOf() - 0.625;
    }
    else if ((currPhase.valueOf() < 0.625) && (currPhase.valueOf() >= 0.5)) {
        phaseProgress = currPhase.valueOf() - 0.5;
    }
    else if ((currPhase.valueOf() < 0.5) && (currPhase.valueOf() >= 0.375)) {
        phaseProgress = currPhase.valueOf() - 0.375;
    }
    else if ((currPhase.valueOf() < 0.375) && (currPhase.valueOf() >= 0.25)) {
        phaseProgress = currPhase.valueOf() - 0.25;
    }
    else if ((currPhase.valueOf() < 0.25) && (currPhase.valueOf() >= 0.125)) {
        phaseProgress = currPhase.valueOf() - 0.125;
    }
    else if (currPhase.valueOf() < 0.125) {
        phaseProgress = currPhase.valueOf()
    }
    else {
        phaseProgress = -1.0;
    }

    let totHrsToNext = hoursPerPhase - (phaseProgress * 100 * daysPerPhase);
    // console.log('totHrsToNext ' + totHrsToNext);
    // console.log('phaseProgress ' + phaseProgress);
    let daysToNext = totHrsToNext / 24;
    let floorDays = Math.floor(daysToNext);
    let fracDays = daysToNext - floorDays;
    let hoursToNext = fracDays * 24;
    let floorHours = Math.floor(hoursToNext);
    let fracHours = hoursToNext - floorHours;
    let minToNext = fracHours * 60;
    let floorMins = Math.floor(minToNext);
    let fracMins = minToNext - floorMins;
    let secToNext = fracMins * 60;
    let floorSecs = Math.floor(secToNext);

    return {
        floorDays, floorHours, floorMins, floorSecs
    }
}

function phaseAt(year, month, day, hour = 0) {
    let currDay = day;

    if (hour < 4) {
        currDay -= 1;
    }
    if (hour > 24) {
        currDay += 1;
    }

    let a = Math.floor(year / 100);
    let b = Math.floor(a / 4);
    let c = 2 - a + b;
    let e = Math.floor(365.25 * (year + 4716));
    let f = Math.floor(30.6001 * (month + 1));
    let jd = c + currDay + e + f - 1524.5;
    let dsn = jd - 2451549.5;
    let nm = dsn / 29.53;
    let nmInt = Math.floor(nm);

    return (nm - nmInt);
}

function phaseInt(phase) {
    return Math.round(phase * 8);
}

function update() {
    let today = new Date(Date.now());
    let s = today.getUTCSeconds();
    let mi = today.getUTCMinutes();
    let h = today.getUTCHours() - 4;
    let d = today.getUTCDate();
    let mo = today.getUTCMonth();
    let y = today.getUTCFullYear();
    let tblRobust = document.getElementById('robust_growing');
    let tblDecent = document.getElementById('decent_growing');
    let tblBoxes = document.getElementById('box_effects');
    let phaser = document.getElementById('phases');
    let boxer = document.getElementById('boxes');
    let untilNext = document.getElementById('until_next');
    let row;
    let icon;
    let name;
    let grwTime;
    let highSubs;
    let lowSubs;
    let phasePick;
    let phaseNum = phaser.selectedIndex;
    let boxType = boxer.selectedIndex;
    let rob = 0;
    let dec = 0;
    let bx = 0;
    let boxMod = boxes[boxType][1][0][0];
    let headerR;
    let bodyR;
    let bodyD;
    let bodyB;

    tblRobust.innerHTML = '';
    tblDecent.innerHTML = '';
    tblBoxes.innerHTML = '';
    untilNext.innerHTML = '';


    headerR = tblRobust.createTHead();
    row = headerR.insertRow(rob);
    icon = row.insertCell(0);
    name = row.insertCell(1);
    grwTime = row.insertCell(2);
    highSubs = row.insertCell(3);
    lowSubs = row.insertCell(4);
    phasePick = row.insertCell(5);

    icon.appendChild(icon.ownerDocument.createTextNode('Icon'));
    name.appendChild(name.ownerDocument.createTextNode('Mushroom'));
    grwTime.appendChild(grwTime.ownerDocument.createTextNode('Time'));
    highSubs.appendChild(highSubs.ownerDocument.createTextNode('High Substrate'));
    lowSubs.appendChild(lowSubs.ownerDocument.createTextNode('Low Substrate'));
    phasePick.appendChild(phasePick.ownerDocument.createTextNode('Phase Ready'));

    bodyR = tblRobust.createTBody();
    bodyD = tblDecent.createTBody();
    bodyB = tblBoxes.createTBody();

    let svrTime = new Date(y, mo, d, h, mi, s, 0);
    let timeNext = timeToNextPhase(svrTime.getFullYear(), svrTime.getMonth(), svrTime.getDate(), svrTime.getHours(),
        svrTime.getMinutes(), svrTime.getSeconds(), 0);
    let sD, sH, sM, sS = 's ';
    svrTime.getDate().valueOf() > 1 ? sD = 's ' : sD = '';
    svrTime.getHours().valueOf() > 1 ? sH = 's ' : sH = '';
    svrTime.getMinutes().valueOf() > 1 ? sM = 's ' : sM = '';
    svrTime.getSeconds().valueOf() > 1 ? sS = 's ' : sS = '';
    let txtNode = (timeNext.floorDays + ' day' + sD + timeNext.floorHours + ' hour' + sH +
        timeNext.floorMins + ' min' + sM + timeNext.floorSecs + ' second' + sS);
    untilNext.appendChild(untilNext.ownerDocument.createTextNode(txtNode));

    for (let mod in boxes[boxType][1]) {
        row = bodyB.insertRow(bx);
        let cell = row.insertCell(0);
        cell.appendChild(cell.ownerDocument.createTextNode(boxes[boxType][1][bx][1]));
        bx += 1;
    }

    for (let shroom in mus) {
        let isRobust = (phaseNum === mus[shroom][5][0]) || (phaseNum === mus[shroom][5][1]);
        let isPoor = (phaseNum === mus[shroom][6][0]) || (phaseNum === mus[shroom][6][1]);
        let isDecent = (!isRobust && isPoor);

        if (isRobust) {
            row = bodyR.insertRow(rob);
            let mushPic = row.insertCell(0);
            let img = document.createElement('img');
            img.src = mus[shroom][4];
            img.width = iconSize;
            img.height = iconSize;
            mushPic.appendChild(img);
            name = row.insertCell(1);
            grwTime = row.insertCell(2);
            highSubs = row.insertCell(3);
            lowSubs = row.insertCell(4);
            phasePick = row.insertCell(5);
            name.appendChild(name.ownerDocument.createTextNode(mus[shroom][0]));
            grwTime.appendChild(grwTime.ownerDocument.createTextNode((mus[shroom][1] * boxMod).toPrecision(2) + ' hours'));
            highSubs.appendChild(highSubs.ownerDocument.createTextNode(mus[shroom][2]));
            lowSubs.appendChild(lowSubs.ownerDocument.createTextNode(mus[shroom][3]));

            let svrTime = new Date(y, mo, d, h, mi, s, 0);
            let rdyHour = svrTime.getHours().valueOf() + (mus[shroom][1] * boxMod.valueOf());

            if (rdyHour < 4) {
                rdyHour += 20;
                d -= 1;
            }
            if (rdyHour >= 24) {
                rdyHour -= 24;
                d += 1;
            }
            let rdyDate = new Date(svrTime.getFullYear(), svrTime.getMonth(), svrTime.getDate(), rdyHour, svrTime.getMinutes(), svrTime.getSeconds(), 0);
            let rdyPhase = phaseInt(phaseAt(rdyDate.getFullYear(), rdyDate.getMonth(), rdyDate.getDate()));
            let rdyText = moonPhasesTxt[rdyPhase];
            phasePick.appendChild(phasePick.ownerDocument.createTextNode(rdyText));
            rob += 1;
        }
        else if (isDecent) {
            row = bodyD.insertRow(dec);
            let mushPic = row.insertCell(0);
            let img = document.createElement('img');
            img.src = mus[shroom][4];
            img.width = iconSize;
            img.height = iconSize;
            mushPic.appendChild(img);
            name = row.insertCell(1);
            grwTime = row.insertCell(2);
            highSubs = row.insertCell(3);
            lowSubs = row.insertCell(4);
            phasePick = row.insertCell(5);
            name.appendChild(name.ownerDocument.createTextNode(mus[shroom][0]));
            grwTime.appendChild(grwTime.ownerDocument.createTextNode((mus[shroom][1] * boxMod.valueOf()).toPrecision(2) + ' hours'));
            highSubs.appendChild(highSubs.ownerDocument.createTextNode(mus[shroom][2]));
            lowSubs.appendChild(lowSubs.ownerDocument.createTextNode(mus[shroom][3]));

            let svrTime = new Date(y, mo, d, h, mi, s, 0);
            let rdyHour = svrTime.getHours().valueOf() + (mus[shroom][1] * boxMod.valueOf());

            if (rdyHour < 4) {
                rdyHour += 20;
                d -= 1;
            }
            if (rdyHour >= 24) {
                rdyHour -= 24;
                d += 1;
            }
            let rdyDate = new Date(svrTime.getFullYear(), svrTime.getMonth(), svrTime.getDate(), rdyHour, svrTime.getMinutes(), svrTime.getSeconds(), 0);
            let rdyPhase = phaseInt(phaseAt(rdyDate.getFullYear(), rdyDate.getMonth(), rdyDate.getDate()));
            let rdyText = moonPhasesTxt[rdyPhase];
            phasePick.appendChild(phasePick.ownerDocument.createTextNode(rdyText));
            dec += 1;
        }
    }
}

function setupApp() {
    let today = new Date(Date.now());
    let s = today.getUTCSeconds();
    let mi = today.getUTCMinutes();
    let h = today.getUTCHours().valueOf() - 4;
    let d = today.getUTCDate();
    let mo = today.getUTCMonth();
    let y = today.getUTCFullYear();
    let phaser = document.getElementById('phases');
    let boxer = document.getElementById('boxes');
    let svrTime = new Date(y, mo, d, h, mi, s, 0);
    let phaseNow = phaseName([phaseAt(svrTime.getFullYear(), svrTime.getMonth(), svrTime.getDate())]);
    let phaseNext = phaseName([phaseAt(svrTime.getFullYear(), svrTime.getMonth(), svrTime.getDate().valueOf() + 3)]);

    let currPhaseElem = document.getElementById('curr_phase');
    currPhaseElem.appendChild(currPhaseElem.ownerDocument.createTextNode(phaseNow));
    let nextPhaseElem = document.getElementById('next_phase');
    nextPhaseElem.appendChild(nextPhaseElem.ownerDocument.createTextNode(phaseNext));

    for (let p in moonPhases) {
        let option = document.createElement('option');
        option.text = moonPhases[p];
        phaser.add(option);
    }
    for (let g in boxes) {
        let option = document.createElement('option');
        option.text = boxes[g][0];
        boxer.add(option);
    }
    phaser.textAlign = 'center';
    boxer.textAlign = 'center';

    phaser.addEventListener('change', (event) => {
        update();
    });
    boxer.addEventListener('change', (event) => {
        update();
    });

    let eventPhase = new Event('change');
    let eventBox = new Event('change');
    phaser.dispatchEvent(eventPhase);
    boxer.dispatchEvent(eventBox);
}

setupApp();
