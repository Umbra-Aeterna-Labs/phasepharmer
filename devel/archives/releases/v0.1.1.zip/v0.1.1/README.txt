### Phase Pharmer ###

A mushroom farming tool for Project: Gorgon (an excellent MMORPG)

Phase Pharmer is a web app that calculates the  current
phase of the moon and provides useful fungal growth information
for avid mushroom farmers

Written in JavaScript

Project: Gorgon website - https://projectgorgon.com


## RELEASES ##
* 16 May 2019: v0.1.0-beta (pre-release)
* for source code see https://github.com/chrismabon/PhasePharmer/tree/master/devel


## KNOWN ISSUES ##
* Time to next phase counter is broken
* Phase ready column is rather inaccurate


## INSTRUCTIONS ##
* Download the latest version of Phase Pharmer at https://github.com/chrismabon/PhasePharmer/releases
* Extract all files to a local folder
* Open PhasePharmer.html in a browser of your choice (IE/Edge untested)
* "Today's Phase" is the calculated moon phase
* Select a phase from the drop-down to view more info
* Every time the page is loaded the phase is recalculated


## LICENSE & COPYRIGHT ##

This project is licensed under the MIT License (MIT)

Copyright &copy; 2019 Chris Mabon
